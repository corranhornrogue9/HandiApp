using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DoubleSidedPanel : MonoBehaviour
{
    public float VerticalPriority = 0;

    public Button spinButton1;
    public Button spinButton2;
    public Canvas side1;
    public Canvas side2;
    public bool backSide = false;
    // Start is called before the first frame update
    void Start()
    {
        if (spinButton1 != null && spinButton2 != null)
        {
            Debug.Log("adding lsitners");
            spinButton1.onClick.AddListener(() =>
            {
                Debug.Log("pressed button");
                backSide = true;
               
            });
            Debug.Log("adding lsitners2");
            spinButton2.onClick.AddListener(() =>
            {
                Debug.Log("pressed button2");
                backSide = false;
            });

        }
    }

    // Update is called once per frame
    void Update()
    {
        if (spinButton1 != null && spinButton2 != null)
        {
            if (backSide)
            {
                transform.rotation = Quaternion.Lerp(transform.rotation, Quaternion.Euler(180, 0, 0), Time.deltaTime * 10);
            }
            else
            {
                transform.rotation = Quaternion.Lerp(transform.rotation, Quaternion.Euler(0,0, 0), Time.deltaTime * 10);
            }

            if (transform.rotation.eulerAngles.y > 90 )
            {
               
                side1.enabled = false;
                side2.enabled = true;

            }
            else
            {
               
              
                side1.enabled = true;
                side2.enabled = false;

            }

        }
    }

    public float Height
    {
        get
        {
            return GetComponentInChildren<Canvas>().GetComponent<RectTransform>().rect.height;
        }
    }

}
