using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Mark : MonoBehaviour
{
    [SerializeField]
    private Text NumberText;

    private int number;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public TimeSpan MarkTime
    {
        get;
        set;
    }

    public int Number
    {
        get
        {
            return number;
        }
        set
        {
            number = value;
            NumberText.text = number.ToString();
        }
    }
}
