using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UIBoatmanger : MonoBehaviour
{
    [SerializeField]
    private Button Finish;

    [SerializeField]
    private Button Finish2;

    [SerializeField]
    private Button MarkButton;

    [SerializeField]
    private Image Progress;

    [SerializeField]
    private InputField Boatname;
    [SerializeField]
    private TextMeshProUGUI BoatnameText;

    [SerializeField]
    private InputField Handicap;

    [SerializeField]
    private TextMeshProUGUI HandicapTime;

    [SerializeField]
    private TextMeshProUGUI MarkTime;

    public GameObject MarkPrefab;

    public DoubleSidedPanel ParnetPanel;

    public bool EndedRace = false;
    public bool BoatFinished = false;
    public bool raceStarted = false;
    private float rebase = 1;
    private float highestIRC = 1;
    private TimeSpan time;
    
    private TimeSpan boatTime;

    private int markNumber = 1;
    public UIRacemanger Rancemanger;
    public double expectedRaceTime = 3600;
    private Mark currentMark;
    // Start is called before the first frame update
    void Start()
    {
        expectedRaceTime = 3600;
        currentMark = null;
        Finish.onClick.AddListener(() =>
        {
            BoatFinished = !BoatFinished;
        });

        Finish2.onClick.AddListener(() =>
        {
            BoatFinished = !BoatFinished;
        });

        MarkButton.onClick.AddListener(() =>
        {
            if (raceStarted && !BoatFinished)
            {
                var newMark = GameObject.Instantiate(MarkPrefab);
                newMark.GetComponent<Mark>().MarkTime = time;
                newMark.transform.parent = Progress.transform;
                newMark.GetComponent<Mark>().Number = markNumber;

                Rancemanger.SubmitMarkTime(time, markNumber);
                currentMark = newMark.GetComponent<Mark>();
                markNumber++;
            }
        });

        Handicap.text = "1.0";

        Finish.enabled = false;
        raceStarted = false;

        Debug.Log("completed start");
    }

    public void StartRace(float rebase, float highestIrc)
    {
        EndedRace = false;

        Boatname.readOnly = true;
        Handicap.readOnly = true;
        Finish.enabled = true;
        this.rebase = rebase;
        raceStarted = true;

        if (ParnetPanel != null)
        {
            ParnetPanel.backSide = true;
        }


    }

    public void UpdateTime(TimeSpan time)
    {
        this.time = time;

        if (!BoatFinished)
        {
            boatTime = time;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (!EndedRace && raceStarted)
        {
            Progress.fillAmount = (boatTime.Ticks * (rebase * GetIRC())) / GetEstimatedTimeLeft().Ticks;
            


            var raceTime = TimeSpan.FromTicks((long)(boatTime.Ticks * GetIRC()));

            HandicapTime.text = raceTime.Hours + ":" + raceTime.Minutes + ":" + raceTime.Seconds;

            var progressWidth = Progress.rectTransform.rect.width;

            foreach (var mark in Progress.transform.GetComponentsInChildren<Mark>())
            {
               
                mark.GetComponent<RectTransform>().anchoredPosition = new Vector2((progressWidth * ((mark.MarkTime.Ticks * (rebase * GetIRC())) / GetEstimatedTimeLeft().Ticks)) , 0);// Progress.GetComponent<RectTransform>().rect.height / 2);
               
            }

            if(currentMark != null)
            {
                var markTime = currentMark.MarkTime - Rancemanger.GetBestTimeForMark(currentMark.Number);

                MarkTime.text = markTime.Hours + ":" + markTime.Minutes + ":" + markTime.Seconds; ;
            }
            else
            {
                MarkTime.text = "00:00:00";
            }

        }
        

        BoatnameText.text = Boatname.text;
       
    }

    public float GetIRC()
    {
        var irc = 1f;
        if (!float.TryParse(Handicap.text, out irc))
        {
            irc = 1f;
        }

        return irc;
    }

    private TimeSpan GetEstimatedTimeLeft()
    {
        double retVal = expectedRaceTime;
        if((time.TotalSeconds  * highestIRC) * 1.1 > expectedRaceTime)
        {
            expectedRaceTime = expectedRaceTime * 1.1 * highestIRC;
            retVal = expectedRaceTime;
         

        }

        return TimeSpan.FromSeconds(retVal);
    }
}
