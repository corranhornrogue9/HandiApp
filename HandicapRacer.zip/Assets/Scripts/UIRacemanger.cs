using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UIRacemanger : MonoBehaviour
{
    [SerializeField]
    private Button StartRaceButton;

    [SerializeField]
    private Button StartRaceFive;

    [SerializeField]
    private Button Finish;

    [SerializeField]
    private Button Finish2;

    [SerializeField]
    private TMP_InputField StartTime;


    [SerializeField]
    private TMP_InputField RaceLength;



    [SerializeField]
    private TextMeshProUGUI RaceTime;

    [SerializeField]
    private TextMeshProUGUI TimeType;

    [SerializeField]
    private VerticalLayoutGroup Boats;

    private List<UIBoatmanger> boatmangers;

    [SerializeField]
    private Button AddBoat;


    [SerializeField]
    private Canvas canvas;

    public GameObject BoatPrefab;

    public GameObject Center;

    private DateTime startTime;
    private DateTime preStratTime;
    private TimeSpan timeToStart;
    private bool raceStarted = false;
    private bool raceFinished = false;
    private bool inPrestart = false;
    private float expectedRaceTime = 3600;

    private Dictionary<int, TimeSpan> MarkTimes;
    
    // Start is called before the first frame update
    void Start()
    {
        expectedRaceTime = 3600;
        MarkTimes = new Dictionary<int, TimeSpan>();
        boatmangers = new List<UIBoatmanger>();
        StartRaceButton.onClick.AddListener(() =>
        {
            if (boatmangers.Count() > 0)
            {
                StartRace();
            }

        });

        StartTime.onValueChanged.AddListener(ExpectedRaceTime);
        RaceLength.onValueChanged.AddListener(ExpectedRaceLength);
        StartRaceFive.onClick.AddListener(() =>
        {
            if (boatmangers.Count() > 0)
            {
                preStratTime = DateTime.Now;
                timeToStart = TimeSpan.FromMinutes(5);
                inPrestart = true;
            }
        });

        Finish.onClick.AddListener(() =>
        {
            raceFinished = true;
            foreach(var baot in boatmangers)
            {
                baot.EndedRace = true;
            }
        });

        Finish2.onClick.AddListener(() =>
        {
            raceFinished = true;
            foreach (var baot in boatmangers)
            {
                baot.EndedRace = true;
            }
        });

        AddBoat.onClick.AddListener(() =>
        {

            if (Center.GetComponent<VerticalCanvasLayout>().totalComersion > 1)
            {
                var newBoat = GameObject.Instantiate(BoatPrefab);
                newBoat.transform.parent = Center.transform;
                boatmangers.Add(newBoat.GetComponentInChildren<UIBoatmanger>());
                newBoat.GetComponentInChildren<UIBoatmanger>().Rancemanger = this;
                Center.GetComponent<VerticalCanvasLayout>().RePos();
                newBoat.GetComponentInChildren<UIBoatmanger>().expectedRaceTime = expectedRaceTime;
            }


        });


    }

    private void ExpectedRaceLength(string time)
    {
        try
        {
            expectedRaceTime =  (float)TimeSpan.Parse(time).TotalSeconds;

            foreach (var baot in boatmangers)
            {
                baot.expectedRaceTime = expectedRaceTime;
            }
        }
        catch
        {

        }
    }


    private void ExpectedRaceTime(string time)
    {
        try
        {
            var starTime = DateTime.Today + TimeSpan.Parse(time);
            if(starTime < DateTime.Now)
            {

            }
            else
            {
                preStratTime = DateTime.Now;
                inPrestart = true;
                timeToStart = starTime - DateTime.Now;
            }
        }
        catch
        {

        }
    }

    private void StartRace()
    {
        var slowestBoat = boatmangers.OrderByDescending(b => b.GetIRC()).First().GetIRC();
        var fastestBoat = boatmangers.OrderBy(b => b.GetIRC()).First().GetIRC();
        var rebase = 1f / slowestBoat;

        foreach (var baot in boatmangers)
        {
            baot.StartRace(rebase, fastestBoat);
        }
        startTime = DateTime.Now;
        raceFinished = false;
        raceStarted = true;
        inPrestart = false;
    }

    // Update is called once per frame
    void Update()
    {
        if(raceStarted && !raceFinished)
        {


            var raceTime = (DateTime.Now - startTime);
            TimeType.text = "Elapsed Time:";
            RaceTime.text = raceTime.Hours + ":" + raceTime.Minutes + ":" + raceTime.Seconds;
            foreach (var boat in boatmangers)
            {
                boat.UpdateTime((DateTime.Now - startTime));
            }
        }
        else if(inPrestart)
        {
            var timeToRace = (timeToStart - (DateTime.Now - preStratTime));
            TimeType.text = "TTS:";
            RaceTime.text =timeToRace.Hours + ":" + timeToRace.Minutes + ":"+  timeToRace.Seconds;
            if((DateTime.Now - preStratTime) > timeToStart)
            {
                StartRace();
            }
        }
        else if(!raceFinished)
        {
            RaceTime.text = "00:00:00";
        }
       
       
    }

    public void SubmitMarkTime(TimeSpan time, int mark)
    {
        TimeSpan oldTime;
        if(MarkTimes.TryGetValue(mark, out oldTime))
        {
            if (oldTime > time)
            {
                MarkTimes[mark] = time;
            }
        }
        else
        {
            MarkTimes.Add(mark, time);
        }

    }

    public TimeSpan GetBestTimeForMark(int i)
    {
        return MarkTimes[i];
    }
}
