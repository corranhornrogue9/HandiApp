using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteAlways]
public class HorizontalSizing : MonoBehaviour
{
    public float ratio = 1;
    // Start is called before the first frame update
    void Start()
    {
        if (Camera.main.orthographic)
        {
            var width = Camera.main.orthographicSize * 2 * ratio * Camera.main.aspect;
            GetComponent<RectTransform>().sizeDelta = new Vector2(width, GetComponent<RectTransform>().sizeDelta.y);


        }
    }

    // Update is called once per frame
    void Update()
    {
 
    }
}
