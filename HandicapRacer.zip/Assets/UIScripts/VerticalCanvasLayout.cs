using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
[ExecuteAlways]
public class VerticalCanvasLayout : MonoBehaviour
{
    public float ratio = 1f;

    public float screenheght;
    public float totalComersion;
    // Start is called before the first frame update
    void Start()
    {
        PostiionElements();
        screenheght = Camera.main.orthographicSize;


    }

    private void PostiionElements()
    {
        if (Camera.main.orthographic)
        {
            var height = Camera.main.orthographicSize * 2 * ratio;
            var cans = new List<DoubleSidedPanel>(GetComponentsInChildren<DoubleSidedPanel>()).OrderBy(a => a.VerticalPriority);
            totalComersion = height / cans.Sum(a => a.Height);
            var currentY = height / 2;
            foreach (var can in cans)
            {
                can.transform.position = new Vector3(can.transform.position.x, currentY - (can.Height / 2));
                currentY -= can.Height;
               
            }



        }
    }

    // Update is called once per frame
    void Update()
    {
        if (screenheght != Camera.main.orthographicSize)
        {
            PostiionElements();
            screenheght = Camera.main.orthographicSize;
        }
    }

    public void RePos()
    {
        PostiionElements();
    }
}
